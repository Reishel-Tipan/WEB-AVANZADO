import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './services.html',
  styleUrl: './services.css'
})
export class Services {
  services = [
    {
      icon: 'laptop-code',
      title: 'Diseño Web',
      description: 'Creamos sitios web modernos, responsivos y atractivos que se adaptan a cualquier dispositivo.'
    },
    {
      icon: 'mobile-alt',
      title: 'Aplicaciones Móviles',
      description: 'Desarrollo de aplicaciones nativas e híbridas para iOS y Android.'
    },
    {
      icon: 'shopping-cart',
      title: 'E-commerce',
      description: 'Soluciones de comercio electrónico completas para vender tus productos en línea.'
    },
    {
      icon: 'search',
      title: 'SEO',
      description: 'Mejoramos tu visibilidad en los motores de búsqueda para atraer más clientes.'
    },
    {
      icon: 'bullhorn',
      title: 'Marketing Digital',
      description: 'Estrategias de marketing online para hacer crecer tu negocio en internet.'
    },
    {
      icon: 'headset',
      title: 'Soporte Técnico',
      description: 'Asistencia técnica especializada para resolver cualquier problema con tu sitio web.'
    }
  ];
}
