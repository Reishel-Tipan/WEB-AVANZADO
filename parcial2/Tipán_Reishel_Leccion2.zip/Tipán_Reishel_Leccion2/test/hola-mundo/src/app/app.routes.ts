import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Services } from './services/services';
import { Projects } from './projects/projects';
import { About } from './about/about';
import { Contact } from './contact/contact';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'services', component: Services },
  { path: 'projects', component: Projects },
  { path: 'about', component: About },
  { path: 'contact', component: Contact },
  { path: '**', redirectTo: '' } // Redirige a home si la ruta no existe
];
