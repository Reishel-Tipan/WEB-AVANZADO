import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './contact.html',
  styleUrl: './contact.css'
})
export class Contact {
  contactForm: FormGroup;
  submitted = false;
  loading = false;

  constructor(private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      subject: ['', [Validators.required, Validators.minLength(5)]],
      message: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  get f() { return this.contactForm.controls; }

  onSubmit() {
    this.submitted = true;

    if (this.contactForm.invalid) {
      return;
    }

    this.loading = true;
    
    // Aquí iría la lógica para enviar el formulario
    console.log('Formulario enviado:', this.contactForm.value);
    
    // Simulamos un envío
    setTimeout(() => {
      this.loading = false;
      alert('¡Mensaje enviado con éxito! Nos pondremos en contacto contigo pronto.');
      this.contactForm.reset();
      this.submitted = false;
    }, 1500);
  }

  // Método para mostrar errores de validación
  getErrorMessage(controlName: string): string {
    const control = this.contactForm.get(controlName);
    
    if (control?.hasError('required')) {
      return 'Este campo es obligatorio';
    } else if (control?.hasError('email')) {
      return 'Por favor ingresa un correo válido';
    } else if (control?.hasError('minlength')) {
      return `Mínimo ${control.errors?.['minlength'].requiredLength} caracteres`;
    }
    
    return '';
  }
}
