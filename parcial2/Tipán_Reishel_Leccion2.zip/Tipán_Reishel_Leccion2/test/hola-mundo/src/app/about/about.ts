import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about.html',
  styleUrl: './about.css'
})
export class About {
  team = [
    {
      name: 'María González',
      role: 'CEO & Fundadora',
      bio: 'Más de 10 años de experiencia en desarrollo web y estrategias digitales.',
      image: 'assets/images/maria.jpg'
    },
    {
      name: 'Carlos Rodríguez',
      role: 'Director de Tecnología',
      bio: 'Experto en arquitectura de software y soluciones escalables.',
      image: 'assets/images/carlos.jpg'
    },
    {
      name: 'Ana Martínez',
      role: 'Diseñadora UX/UI',
      bio: 'Especializada en crear experiencias de usuario excepcionales.',
      image: 'assets/images/ana.jpg'
    }
  ];

  stats = [
    { value: '200+', label: 'Proyectos Completados' },
    { value: '98%', label: 'Clientes Satisfechos' },
    { value: '10+', label: 'Años de Experiencia' },
    { value: '50+', label: 'Profesionales' }
  ];

  // Manejador de errores para imágenes
  handleImageError(event: any) {
    // Si hay un error al cargar la imagen, mostramos una imagen por defecto
    event.target.src = 'assets/images/logo.png';
    event.target.alt = 'Imagen no disponible';
  }
}
