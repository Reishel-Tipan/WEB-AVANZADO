import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './projects.html',
  styleUrl: './projects.css'
})
export class Projects {
  projects = [
    {
      title: 'Campeonato Interurbanización Website',
      description: 'Proyecto web desarrollado con HTML y CSS para la organización de un campeonato de fútbol. Incluye secciones como calendario de partidos, tabla de posiciones, goleadores, tarjetas rojas y más.',
      image: 'assets/images/proyecto1.png',
      githubUrl: 'https://github.com/Reishel-Tipan/Pagina-Campeonatos/tree/main/proyecto_web'
    },
    {
      title: 'Sistema de Alquiler de Vehículos',
      description: 'Sistema de alquiler de vehículos desarrollado en Visual Studio 2022 con .NET y arquitectura por capas. Permite gestionar reservas, pagos y seguros, integrando base de datos SQL Server y funcionalidades administrativas para el control eficiente del servicio.',
      image: 'assets/images/proyecto2.png',
      githubUrl: 'https://github.com/Reishel-Tipan/Sistema-Alquiler-Vehiculos'
    },
    {
      title: 'Gestión de Subasta de Autos',
      description: 'Proyecto de base de datos para un sistema de subastas de autos, desarrollado en MySQL Workbench. Se crearon tablas, relaciones, consultas SQL, vistas, funciones y procedimientos almacenados, incluyendo gestión de usuarios, pujas, pagos y auditoría.',
      image: 'assets/images/proyecto3.jpeg',
      githubUrl: 'https://github.com/Reishel-Tipan/Base-Datos/tree/main/Bonilla_Guallichico_Salcedo_Tipan'
    }
  ];
}
