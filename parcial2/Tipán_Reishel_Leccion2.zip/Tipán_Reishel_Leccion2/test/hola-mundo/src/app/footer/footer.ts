import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './footer.html',
  styleUrl: './footer.css'
})
export class Footer {
  currentYear = new Date().getFullYear();
  
  // Enlaces rápidos
  quickLinks = [
    { name: 'Inicio', path: '/' },
    { name: 'Servicios', path: '/services' },
    { name: 'Proyectos', path: '/projects' },
    { name: 'Nosotros', path: '/about' },
    { name: 'Contacto', path: '/contact' }
  ];

  // Servicios
  services = [
    { name: 'Diseño Web', path: '/services#web-design' },
    { name: 'Desarrollo a Medida', path: '/services#custom-development' },
    { name: 'Marketing Digital', path: '/services#digital-marketing' },
    { name: 'SEO', path: '/services#seo' },
    { name: 'Mantenimiento', path: '/services#maintenance' }
  ];

  // Redes sociales
  socialLinks = [
    { icon: 'facebook-f', url: 'https://facebook.com' },
    { icon: 'twitter', url: 'https://twitter.com' },
    { icon: 'instagram', url: 'https://instagram.com' },
    { icon: 'linkedin-in', url: 'https://linkedin.com' },
    { icon: 'youtube', url: 'https://youtube.com' }
  ];
}
