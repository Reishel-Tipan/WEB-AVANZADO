import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class Home {
  // Datos de ejemplo para las características
  features = [
    {
      icon: 'fas fa-rocket',
      title: 'Diseño Moderno',
      description: 'Creamos sitios web atractivos y funcionales que se adaptan a cualquier dispositivo.'
    },
    {
      icon: 'fas fa-mobile-alt',
      title: 'Responsive',
      description: 'Todos nuestros diseños son completamente adaptables a móviles, tabletas y escritorio.'
    },
    {
      icon: 'fas fa-tachometer-alt',
      title: 'Alto Rendimiento',
      description: 'Optimización de velocidad y rendimiento para ofrecer la mejor experiencia de usuario.'
    },
    {
      icon: 'fas fa-cog',
      title: 'Personalizable',
      description: 'Soluciones a medida que se adaptan a las necesidades específicas de tu negocio.'
    }
  ];

  // Datos de ejemplo para los testimonios
  testimonials = [
    {
      quote: 'Increíble trabajo y atención al detalle. ¡Altamente recomendados!',
      author: 'María González',
      role: 'CEO, Empresa XYZ'
    },
    {
      quote: 'El mejor equipo con el que he trabajado. Profesionales y comprometidos.',
      author: 'Carlos Martínez',
      role: 'Director de Marketing'
    },
    {
      quote: 'Resultados excepcionales que superaron nuestras expectativas.',
      author: 'Ana López',
      role: 'Emprendedora'
    }
  ];
}
